# TCL Nova Remote — Android (v0.1, protótipo)

Controle remoto **nativo em Java**, **sem anúncios, analytics ou conta**, feito para celulares Android e TVs Android TV/Google TV com **Android TV Remote Service v2**. Não modifica o TCL Nova Launcher nem instala serviços extras na TV.

## Recursos

- Pareamento do dispositivo via código hexadecimal de 6 caracteres mostrado na TV.
- Cliente TLS com certificado próprio no AndroidKeyStore e pinagem do certificado apresentado no pareamento.
- Direcional, OK, Home, Voltar, Menu, energia, volume, mudo, reprodução e atalhos por deep-link.
- Toque com vibração e repetição em pressões longas.
- Conexão persistente enquanto o app estiver aberto; responde aos pings de controle.
- Endereço IP salvo localmente; sem bibliotecas de terceiros no app.

## Como compilar

1. Abra **TCL-Nova-Remote** como projeto no **Android Studio**, usando **JDK 17** e SDK Android 35.
2. Se o Android Studio solicitar instalação de Gradle, use versão **8.9**. Projeto preparado para AGP 8.7.3.
3. Em **Build > Build Bundle(s) / APK(s) > Build APK(s)**, gere `app/build/outputs/apk/debug/app-debug.apk`.
4. Instale **no celular**, não na TV. Celular e TV devem estar na mesma rede local.
5. Informe o IP atual da TV (campo pré-preenchido com o IP usado no projeto anterior).
6. Toque em **Conectar**, digite o código exibido na TV e toque em **Parear**.
7. Nas próximas conexões, bastará tocar em **Conectar**.

### Compilar pelo GitHub Actions

Este projeto inclui `.github/workflows/android.yml`. Ao colocar os arquivos na raiz de um repositório GitHub, o workflow executa `gradle :app:assembleDebug` e disponibiliza o APK como artefato. Não precisa de Android Studio nesse caminho.

## Compatibilidade e limites

- **Não testado em TV física ou celular neste ambiente.** Código-fonte de protótipo compilável, mas não entregue como APK validado.
- Depende de o serviço `Android TV Remote Service` estar habilitado e disponível nas portas TCP **6467** (pareamento) e **6466** (controle). No firmware TCL pode ser necessário verificar o nome e o status desse serviço.
- Esses atalhos de aplicativos são *links* e não comandos de abrir pacote: a TV pode ignorar ou abrir no navegador, dependendo de aplicativos/associações.
- Em algumas TVs, o botão Power apenas suspende o Android TV; ligar a TV de um desligamento total pode depender do hardware/CEC.
- O servidor usa certificados autoassinados e é identificado após o pareamento via código. O aplicativo confere a identidade salva ao reconectar.
- O pareamento usa identidade guardada no AndroidKeyStore; limpar os dados do app ou reinstalá-lo pode exigir novo pareamento.
- É um protótipo v0.1: sem descoberta automática, teclado remoto nem microfone. Estes podem ser adicionados depois do primeiro teste real.

## Segurança

O app usa apenas Wi-Fi local para controlar a TV. **Não precisa de depuração ADB nem da porta 5555**, que você poderá desligar após comprovar que o app funciona.

Referência da especificação/protocolo: [androidtvremote2](https://github.com/tronikos/androidtvremote2), Apache-2.0. A implementação do MVP é própria e usa codificação protobuf mínima.

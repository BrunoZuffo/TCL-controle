package br.com.tclnova.remote;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Minimal length-delimited protobuf codec; no runtime dependency. */
final class Proto {
    private final ByteArrayOutputStream buffer = new ByteArrayOutputStream();

    Proto number(int field, long value) {
        varint(buffer, ((long)field << 3));
        varint(buffer, value);
        return this;
    }

    Proto bytes(int field, byte[] value) {
        varint(buffer, ((long)field << 3) | 2);
        varint(buffer, value.length);
        buffer.write(value, 0, value.length);
        return this;
    }

    Proto text(int field, String value) { return bytes(field, value.getBytes(StandardCharsets.UTF_8)); }
    Proto message(int field, Proto value) { return bytes(field, value.toByteArray()); }
    byte[] toByteArray() { return buffer.toByteArray(); }

    static void writeFrame(OutputStream out, Proto msg) throws IOException {
        byte[] b = msg.toByteArray();
        varint(out, b.length);
        out.write(b);
        out.flush();
    }

    static Map<Integer, Object> readFrame(InputStream in) throws IOException {
        long count = readVarint(in);
        if (count < 0 || count > 1024 * 1024) throw new IOException("Invalid message size: " + count);
        byte[] raw = readExact(in, (int)count);
        return decode(raw);
    }

    static Map<Integer, Object> decode(byte[] src) throws IOException {
        Map<Integer, Object> fields = new HashMap<>();
        ByteArrayInputStream in = new ByteArrayInputStream(src);
        while (in.available() > 0) {
            long tag = readVarint(in);
            int field = (int)(tag >>> 3), type = (int)(tag & 7);
            if (field <= 0) throw new IOException("Invalid protobuf tag");
            if (type == 0) {
                fields.put(field, readVarint(in));
            } else if (type == 2) {
                long n = readVarint(in);
                if (n > in.available() || n < 0) throw new EOFException("Bad protobuf size");
                byte[] raw = readExact(in, (int)n);
                fields.put(field, raw);
            } else if (type == 1) {
                if (in.skip(8) != 8) throw new EOFException();
            } else if (type == 5) {
                if (in.skip(4) != 4) throw new EOFException();
            } else {
                throw new IOException("Unknown protobuf wire type " + type);
            }
        }
        return fields;
    }

    static Map<Integer, Object> nested(Map<Integer, Object> m, int field) throws IOException {
        Object o = m.get(field);
        return o instanceof byte[] ? decode((byte[])o) : new HashMap<>();
    }
    static long number(Map<Integer,Object> m,int field) {
        Object v=m.get(field);return v instanceof Long?(Long)v:0L;
    }
    static boolean has(Map<Integer, Object> m, int field) { return m.containsKey(field); }

    private static byte[] readExact(InputStream in, int n) throws IOException {
        byte[] b=new byte[n];
        int pos=0;
        while(pos<n) {
            int got=in.read(b,pos,n-pos);
            if(got<0) throw new EOFException("Unexpected end of TV stream");
            if(got==0) continue;
            pos+=got;
        }
        return b;
    }

    static void varint(OutputStream out, long value) {
        try {
            while ((value & ~0x7fL) != 0) {
                out.write((int)(value & 0x7f) | 0x80);
                value >>>= 7;
            }
            out.write((int)value);
        } catch (IOException ex) {
            throw new IllegalStateException(ex);
        }
    }
    static long readVarint(InputStream in) throws IOException {
        long result=0;
        for (int i=0; i<10; i++) {
            int b=in.read();
            if (b<0) throw new EOFException("No more data");
            result |= ((long)(b & 0x7f)) << (i*7);
            if ((b & 0x80) == 0) return result;
        }
        throw new IOException("Varint too long");
    }
}

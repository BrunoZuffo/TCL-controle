package br.com.tclnova.remote;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Small, native, dependency-free Android phone UI. */
public final class MainActivity extends Activity {
    private static final int BG=0xff0b1020, PANEL=0xff18233b, PRIMARY=0xff2dd4bf,
        TEXT=Color.WHITE, SECONDARY=0xff9caac3, RED=0xffe45c75;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private TvClient tv;
    private EditText ip,code;
    private TextView status;
    private LinearLayout pairSection;
    private Button connect;
    private boolean configuring;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        tv=new TvClient(this,()->ui.post(()->{
            if (!configuring) showStatus("TV desconectada. Toque em Conectar.",false);
        }));
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(25),dp(22),dp(30));
        scroll.addView(root);

        TextView brand=text("TCL / NOVA",14,PRIMARY,true);
        brand.setLetterSpacing(.18f);
        root.addView(brand);
        TextView title=text("Controle remoto",29,TEXT,true);
        margin(root,title,0,6,0,4);
        TextView subtitle=text("Rápido • Sem anúncios • Só na rede local",12,SECONDARY,false);
        margin(root,subtitle,0,0,0,20);

        status=text("Não conectado",13,SECONDARY,false);
        status.setPadding(dp(14),dp(12),dp(14),dp(12));
        status.setBackground(bg(PANEL,13));
        margin(root,status,0,0,0,13);

        LinearLayout connectLine=horizontal();
        root.addView(connectLine);
        ip=new EditText(this);
        ip.setSingleLine(true);
        ip.setTextColor(TEXT);
        ip.setHintTextColor(SECONDARY);
        ip.setTextSize(15);
        ip.setPadding(dp(14),0,dp(12),0);
        ip.setBackground(bg(PANEL,12));
        ip.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        ip.setHint("IP da TV");
        ip.setText(getPreferences(MODE_PRIVATE).getString("host","192.168.0.229"));
        connectLine.addView(ip,new LinearLayout.LayoutParams(0,dp(52),1));
        connect=button("Conectar",PRIMARY,BG);
        LinearLayout.LayoutParams connP=new LinearLayout.LayoutParams(dp(102),dp(52));
        connP.leftMargin=dp(9);
        connectLine.addView(connect,connP);
        connect.setOnClickListener(v->connect());

        pairSection=vertical();
        pairSection.setPadding(dp(15),dp(12),dp(15),dp(14));
        pairSection.setBackground(bg(PANEL,14));
        margin(root,pairSection,0,12,0,4);
        pairSection.addView(text("Código de pareamento exibido na TV",13,TEXT,true));
        LinearLayout pairLine=horizontal();
        margin(pairSection,pairLine,0,9,0,0);
        code=new EditText(this);
        code.setSingleLine(true);
        code.setAllCaps(true);
        code.setTextColor(TEXT);
        code.setHintTextColor(SECONDARY);
        code.setHint("Ex.: 9A12BC");
        code.setTextSize(17);
        code.setPadding(dp(10),0,dp(10),0);
        code.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        code.setBackground(bg(0xff0b152a,10));
        pairLine.addView(code,new LinearLayout.LayoutParams(0,dp(48),1));
        Button pairBtn=button("Parear",PRIMARY,BG);
        LinearLayout.LayoutParams pairP=new LinearLayout.LayoutParams(dp(92),dp(48));
        pairP.leftMargin=dp(8);
        pairLine.addView(pairBtn,pairP);
        pairBtn.setOnClickListener(v->finishPair());
        pairSection.setVisibility(View.GONE);

        LinearLayout bar=horizontal();
        bar.setGravity(Gravity.CENTER);
        margin(root,bar,0,24,0,22);
        remoteButton(bar,"⏻",26,dp(70),dp(58),26); // power
        addGap(bar,11);
        remoteButton(bar,"Vol −",25,0,dp(58),0);
        addGap(bar,9);
        remoteButton(bar,"Vol +",24,0,dp(58),0);
        addGap(bar,9);
        remoteButton(bar,"Mudo",164,0,dp(58),0);

        root.addView(text("NAVEGAÇÃO",11,SECONDARY,true));
        LinearLayout dpad=vertical();
        dpad.setGravity(Gravity.CENTER);
        margin(root,dpad,0,12,0,15);
        dpadRow(dpad,new String[]{"","▲",""},new int[]{-1,19,-1});
        dpadRow(dpad,new String[]{"◀","OK","▶"},new int[]{21,23,22});
        dpadRow(dpad,new String[]{"","▼",""},new int[]{-1,20,-1});

        LinearLayout nav=horizontal();
        margin(root,nav,0,0,0,22);
        remoteButton(nav,"↶  Voltar",4,0,dp(54),0);
        addGap(nav,10);
        remoteButton(nav,"⌂  Home",3,0,dp(54),0);
        addGap(nav,10);
        remoteButton(nav,"☰",82,dp(62),dp(54),0);

        root.addView(text("REPRODUÇÃO",11,SECONDARY,true));
        LinearLayout media=horizontal();
        margin(root,media,0,12,0,23);
        remoteButton(media,"⏪",89,0,dp(54),0);
        addGap(media,10);
        remoteButton(media,"▶ / ❚❚",85,0,dp(54),0);
        addGap(media,10);
        remoteButton(media,"⏩",90,0,dp(54),0);

        root.addView(text("ABRIR APLICATIVOS",11,SECONDARY,true));
        LinearLayout apps=horizontal();
        margin(root,apps,0,12,0,16);
        appButton(apps,"YouTube","https://www.youtube.com");
        addGap(apps,9);
        appButton(apps,"Netflix","https://www.netflix.com");
        addGap(apps,9);
        appButton(apps,"Prime","https://www.primevideo.com");
        root.addView(text("Os atalhos dependem dos links aceitos pelos apps instalados na TV.",11,SECONDARY,false));
        setContentView(scroll);
    }

    private void dpadRow(LinearLayout area,String[] labels,int[] keys) {
        LinearLayout row=horizontal();
        row.setGravity(Gravity.CENTER);
        area.addView(row);
        for (int i=0;i<3;i++) {
            if (keys[i]<0) {
                View spacer=new View(this);
                row.addView(spacer,new LinearLayout.LayoutParams(dp(86),dp(76)));
            } else {
                Button b=button(labels[i],keys[i]==23?PRIMARY:PANEL,keys[i]==23?BG:TEXT);
                b.setTextSize(keys[i]==23?17:25);
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(80),dp(70));
                lp.setMargins(dp(3),dp(3),dp(3),dp(3));
                row.addView(b,lp);
                addRepeatHandler(b,keys[i]);
            }
        }
    }

    private void remoteButton(LinearLayout row,String label,int key,int w,int h,int font) {
        Button b=button(label,PANEL,TEXT);
        if(font>0)b.setTextSize(font);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w==0?0:w,h,w==0?1:0);
        row.addView(b,p);
        addRepeatHandler(b,key);
    }

    private void appButton(LinearLayout row,String label,String link) {
        Button b=button(label,PANEL,TEXT);
        b.setTextSize(12);
        row.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));
        b.setOnClickListener(v-> {
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            io.execute(()->{
                try {tv.openApp(link);}catch(Exception ex){error(ex);}
            });
        });
    }

    private void addRepeatHandler(Button b,int key) {
        final Runnable[] repeat={null};
        b.setOnTouchListener((v,event)->{
            if(event.getActionMasked()==MotionEvent.ACTION_DOWN){
                v.setPressed(true);
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                send(key);
                repeat[0]=new Runnable(){
                    @Override public void run(){
                        if(v.isPressed()){send(key);ui.postDelayed(this,135);}
                    }
                };
                ui.postDelayed(repeat[0],460);
                return true;
            }
            if(event.getActionMasked()==MotionEvent.ACTION_UP || event.getActionMasked()==MotionEvent.ACTION_CANCEL){
                v.setPressed(false);
                if(repeat[0]!=null) ui.removeCallbacks(repeat[0]);
                return true;
            }
            return true;
        });
    }

    private void send(int key){io.execute(()->{
        try{tv.key(key);}catch(Exception ex){error(ex);}
    });}

    private void connect(){
        if(configuring)return;
        String host=ip.getText().toString().trim();
        if(!host.matches("[a-zA-Z0-9.-]{1,253}")){
            showStatus("Digite um IP válido, sem porta (ex.: 192.168.0.229)",false);return;
        }
        getPreferences(MODE_PRIVATE).edit().putString("host",host).apply();
        pairSection.setVisibility(View.GONE);
        configuring=true;
        connect.setEnabled(false);
        showStatus("Conectando à TV...",true);
        io.execute(()->{
            try {
                if(tv.paired(host)){
                    tv.connectRemote(host);
                    ui.post(()->{
                        configuring=false;connect.setEnabled(true);
                        showStatus("✓ Conectado à TCL. Controle pronto!",true);
                    });
                }else{
                    tv.beginPairing(host);
                    ui.post(()->{
                        configuring=false;connect.setEnabled(true);
                        pairSection.setVisibility(View.VISIBLE);
                        showStatus("Confira a TV e digite o código de pareamento.",true);
                    });
                }
            }catch(Exception ex){
                ui.post(()->{configuring=false;connect.setEnabled(true);showStatus("Falha ao conectar: "+nice(ex),false);});
            }
        });
    }

    private void finishPair(){
        if(configuring)return;
        configuring=true;
        showStatus("Autenticando com a TV...",true);
        String pin=code.getText().toString().trim().toUpperCase(Locale.ROOT);
        String host=ip.getText().toString().trim();
        io.execute(()->{
            try{
                tv.finishPairing(pin);
                tv.connectRemote(host);
                ui.post(()->{
                    configuring=false;
                    pairSection.setVisibility(View.GONE);
                    showStatus("✓ Pareado e conectado. Pronto para usar!",true);
                });
            }catch(Exception ex){
                ui.post(()->{
                    configuring=false;
                    showStatus("Erro ao parear: "+nice(ex),false);
                });
            }
        });
    }

    private void error(Exception ex){ui.post(()->showStatus("Comando não enviado: "+nice(ex),false));}
    private static String nice(Exception ex){
        String msg=ex.getMessage();return msg==null?ex.getClass().getSimpleName():msg;
    }
    private void showStatus(String message,boolean good){
        status.setText(message);
        status.setTextColor(good?PRIMARY:SECONDARY);
    }

    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private Button button(String label,int back,int foreground){
        Button b=new Button(this);
        b.setText(label);
        b.setTextColor(foreground);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setPadding(dp(2),0,dp(2),0);
        b.setBackground(bg(back,15));
        b.setStateListAnimator(null);
        return b;
    }
    private GradientDrawable bg(int color,int radius){
        GradientDrawable shape=new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }
    private void addGap(LinearLayout row,int gap){row.addView(new View(this),new LinearLayout.LayoutParams(dp(gap),1));}
    private void margin(LinearLayout row,View view,int left,int top,int right,int bottom){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(left),dp(top),dp(right),dp(bottom));row.addView(view,lp);
    }
    private int dp(float x){return (int)(getResources().getDisplayMetrics().density*x+0.5f);}
    @Override public void onDestroy(){tv.close();io.shutdownNow();super.onDestroy();}
}

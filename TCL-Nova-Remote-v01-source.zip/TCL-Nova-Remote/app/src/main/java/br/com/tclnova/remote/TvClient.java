package br.com.tclnova.remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.io.IOException;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.security.auth.x500.X500Principal;

/** Android TV Remote v2 client (TLS + framed protobuf), no ADB and no external SDK. */
final class TvClient {
    interface Listener { void onConnectionLost(); }
    private static final String ALIAS = "tcl_nova_remote_client_identity";
    private static final int FEATURES = 1 | 2 | 32 | 64 | 512; // ping,key,power,volume,app links
    private final SharedPreferences prefs;
    private final Listener listener;
    private SSLContext tls;
    private SSLSocket pairingSocket;
    private SSLSocket remoteSocket;
    private String pairingHost;
    private String pendingPin;
    private X509Certificate peerForPairing;
    private X509Certificate ownCertificate;
    private int activeFeatures=FEATURES;
    private volatile boolean ready;

    TvClient(Context context, Listener listener) {
        this.prefs = context.getSharedPreferences("tcl_nova_remote", Context.MODE_PRIVATE);
        this.listener = listener;
    }

    private synchronized void ensureTls() throws Exception {
        if (tls != null) return;
        KeyStore keys = KeyStore.getInstance("AndroidKeyStore");
        keys.load(null);
        if (!keys.containsAlias(ALIAS)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN)
                .setKeySize(2048)
                .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA1)
                .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                .setCertificateSubject(new X500Principal("CN=TCL Nova Remote"))
                .setCertificateSerialNumber(BigInteger.ONE)
                .setCertificateNotBefore(new Date(0))
                .setCertificateNotAfter(new Date(2524608000000L))
                .build());
            generator.generateKeyPair();
            keys.load(null);
        }
        Certificate cert = keys.getCertificate(ALIAS);
        if (!(cert instanceof X509Certificate)) throw new IOException("Client certificate unavailable");
        ownCertificate=(X509Certificate)cert;
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(keys, null);
        X509TrustManager tvSelfSigned = new X509TrustManager() {
            @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            @Override public void checkClientTrusted(X509Certificate[] chain, String authType) { }
            @Override public void checkServerTrusted(X509Certificate[] chain, String authType) { }
        };
        tls = SSLContext.getInstance("TLS");
        tls.init(kmf.getKeyManagers(), new TrustManager[]{tvSelfSigned}, new SecureRandom());
    }

    private SSLSocket open(String host, int port) throws Exception {
        ensureTls();
        SSLSocket s = (SSLSocket) tls.getSocketFactory().createSocket();
        s.connect(new InetSocketAddress(host, port), 3000);
        s.setSoTimeout(10000);
        s.startHandshake();
        return s;
    }

    private static X509Certificate certificate(SSLSocket s) throws Exception {
        return (X509Certificate)s.getSession().getPeerCertificates()[0];
    }

    /** Starts Polo pairing; completes after the TV has put a six-digit hex code on-screen. */
    synchronized void beginPairing(String host) throws Exception {
        closePairing();
        pairingSocket = open(host, 6467);
        pairingHost=host;
        peerForPairing=certificate(pairingSocket);
        // OuterMessage: version=2, status=200, request(service_name,client_name)
        pairSend(10, new Proto().text(1, "atvremote").text(2, "TCL Nova Remote"));
        pairExpect(11); // pairing_request_ack
        Proto encoding = new Proto().number(1,3).number(2,6); // hexadecimal, six symbols
        pairSend(20, new Proto().message(1,encoding).number(3,1));
        pairExpect(20); // options from TV
        pairSend(30, new Proto().message(1,encoding).number(2,1));
        pairExpect(31); // configuration_ack
        pairingSocket.setSoTimeout(0); // human may need time to read/type the TV code
    }

    private void pairSend(int field, Proto value) throws IOException {
        Proto.writeFrame(pairingSocket.getOutputStream(), new Proto().number(1,2).number(2,200).message(field,value));
    }
    private Map<Integer,Object> pairExpect(int field) throws IOException {
        Map<Integer,Object> msg=Proto.readFrame(pairingSocket.getInputStream());
        if (Proto.number(msg,2)!=200 || !Proto.has(msg,field))
            throw new IOException("Unexpected TV pairing response (wanted "+field+")");
        return msg;
    }

    /** Validates the on-screen checksum BEFORE sending a pairing secret. */
    synchronized void finishPairing(String code) throws Exception {
        if (pairingSocket==null || pairingHost==null) throw new IOException("Pairing has not started");
        code=code.trim().toUpperCase(java.util.Locale.ROOT);
        if (!code.matches("[0-9A-F]{6}")) throw new IOException("Enter the 6-character hexadecimal code on TV");
        RSAPublicKey client=(RSAPublicKey)ownCertificate.getPublicKey();
        RSAPublicKey server=(RSAPublicKey)peerForPairing.getPublicKey();
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        md.update(unsigned(client.getModulus()));
        md.update(unsigned(client.getPublicExponent()));
        md.update(unsigned(server.getModulus()));
        md.update(unsigned(server.getPublicExponent()));
        md.update(hex(code.substring(2)));
        byte[] secret=md.digest();
        if ((secret[0]&255)!=Integer.parseInt(code.substring(0,2),16))
            throw new IOException("Wrong code for this TV; please check and try again");
        pairingSocket.setSoTimeout(10000);
        pairSend(40,new Proto().bytes(1,secret));
        pairExpect(41);
        prefs.edit().putString("pin_"+pairingHost, fingerprint(peerForPairing))
            .putBoolean("paired_"+pairingHost,true).apply();
        closePairing();
    }

    synchronized void connectRemote(String host) throws Exception {
        closeRemote();
        SSLSocket s=open(host,6466);
        try {
            X509Certificate cert=certificate(s);
            String stored=prefs.getString("pin_"+host, null);
            if (stored!=null && !stored.equals(fingerprint(cert)))
                throw new SecurityException("TV identity changed. Clear saved app data to pair again.");
            s.setSoTimeout(18000); // 3 missed pings roughly equals lost connection
            remoteSocket=s;
            ready=false;
            activeFeatures=FEATURES;
            CountDownLatch started=new CountDownLatch(1);
            AtomicReference<Throwable> failure=new AtomicReference<>();
            Thread reader=new Thread(()->readRemote(s,started,failure),"tcl-nova-tv-reader");
            reader.setDaemon(true);
            reader.start();
            if (!started.await(12,TimeUnit.SECONDS))
                throw new IOException("TV remote service did not complete handshake");
            if (failure.get()!=null) throw new IOException("TV disconnected during handshake",failure.get());
            if (!ready) throw new IOException("TV refused remote connection; pair again");
        } catch(Exception ex) {
            try { s.close(); } catch(IOException ignored) { }
            if (remoteSocket==s) remoteSocket=null;
            throw ex;
        }
    }

    private void readRemote(SSLSocket s, CountDownLatch started,AtomicReference<Throwable> failure) {
        try {
            while (!s.isClosed()) {
                Map<Integer,Object> msg=Proto.readFrame(s.getInputStream());
                if (Proto.has(msg,1)) {
                    Map<Integer,Object> cfg=Proto.nested(msg,1);
                    int flags=(int)Proto.number(cfg,1);
                    activeFeatures=FEATURES & flags;
                    Proto info=new Proto().number(3,1).text(4,"1")
                        .text(5,"br.com.tclnova.remote").text(6,"0.1.0");
                    writeTo(s,new Proto().message(1,new Proto().number(1,activeFeatures).message(2,info)));
                } else if (Proto.has(msg,2)) {
                    writeTo(s,new Proto().message(2,new Proto().number(1,activeFeatures)));
                } else if (Proto.has(msg,8)) {
                    long n=Proto.number(Proto.nested(msg,8),1);
                    writeTo(s,new Proto().message(9,new Proto().number(1,n)));
                } else if (Proto.has(msg,40)) {
                    ready=true;
                    started.countDown();
                } else if (Proto.has(msg,3)) {
                    throw new IOException("Remote service returned an error");
                }
            }
        } catch(Throwable ex) {
            failure.set(ex);
        } finally {
            started.countDown();
            if (remoteSocket==s) {
                ready=false;
                remoteSocket=null;
                listener.onConnectionLost();
            }
            try{s.close();}catch(IOException ignored){}
        }
    }

    private static void writeTo(SSLSocket s, Proto msg) throws IOException {
        synchronized(s) { Proto.writeFrame(s.getOutputStream(),msg); }
    }

    boolean isConnected() {return ready && remoteSocket!=null && !remoteSocket.isClosed();}

    void key(int code) throws IOException {
        SSLSocket s=remoteSocket;
        if (!isConnected() || s==null) throw new IOException("Connect to TV first");
        // SHORT=3 per RemoteDirection, standard Android KeyEvent key codes
        writeTo(s,new Proto().message(10,new Proto().number(1,code).number(2,3)));
    }

    void openApp(String url) throws IOException {
        SSLSocket s=remoteSocket;
        if (!isConnected() || s==null) throw new IOException("Connect to TV first");
        writeTo(s,new Proto().message(90,new Proto().text(1,url)));
    }

    boolean paired(String host) {return prefs.getBoolean("paired_"+host,false);}
    synchronized void closePairing() {
        if(pairingSocket!=null) {try{pairingSocket.close();}catch(IOException ignored){} pairingSocket=null;}
        pairingHost=null;
        peerForPairing=null;
    }
    synchronized void closeRemote() {
        ready=false;
        if(remoteSocket!=null) {try{remoteSocket.close();}catch(IOException ignored){} remoteSocket=null;}
    }
    void close() {closePairing();closeRemote();}

    private static byte[] unsigned(BigInteger i) {
        byte[] data=i.toByteArray();
        return data.length>1 && data[0]==0 ? Arrays.copyOfRange(data,1,data.length):data;
    }
    private static byte[] hex(String s) {
        byte[] out=new byte[s.length()/2];
        for(int i=0;i<out.length;i++)out[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);
        return out;
    }
    private static String fingerprint(X509Certificate c) throws Exception {
        byte[] b=MessageDigest.getInstance("SHA-256").digest(c.getEncoded());
        StringBuilder sb=new StringBuilder();for(byte x:b)sb.append(String.format("%02x",x&255));
        return sb.toString();
    }
}
